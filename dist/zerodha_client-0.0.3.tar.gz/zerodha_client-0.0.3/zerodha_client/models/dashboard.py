class DashboardDetails:
    investment_amount = None
    current_value = None

    def __init__(self, investment_amount, current_value):
        self.investment_amount = investment_amount
        self.current_value = current_value
